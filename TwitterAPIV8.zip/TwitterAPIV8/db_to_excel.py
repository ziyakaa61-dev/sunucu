import sqlite3
import pandas as pd
from datetime import datetime
from dateutil import parser  # farklı tarih formatlarını tanır

# Veritabanı bağlantısı
conn = sqlite3.connect("haberler.db")

# Veriyi al
df = pd.read_sql_query("SELECT * FROM haberler", conn)
conn.close()

def tarih_duzelt(x):
    """Farklı tarih formatlarını Türkçe biçime çevirir"""
    if not isinstance(x, str) or len(x.strip()) == 0:
        return ""
    try:
        tarih = parser.parse(x)
        aylar = {
            "January": "Ocak", "February": "Şubat", "March": "Mart", "April": "Nisan",
            "May": "Mayıs", "June": "Haziran", "July": "Temmuz", "August": "Ağustos",
            "September": "Eylül", "October": "Ekim", "November": "Kasım", "December": "Aralık"
        }
        cevrilmis = tarih.strftime("%d %B %Y %A %H:%M")
        for en, tr in aylar.items():
            cevrilmis = cevrilmis.replace(en, tr)
        return cevrilmis
    except Exception:
        return x  # çevrilemeyen formatları olduğu gibi bırak

# Tarih kolonlarını düzelt
for col in ["haber_tarihi", "cekim_tarihi"]:
    if col in df.columns:
        df[col] = df[col].apply(tarih_duzelt)

# Excel dosyasına kaydet
excel_dosya = "haberler_excel.xlsx"
df.to_excel(excel_dosya, index=False)
print(f"📊 Haberler başarıyla '{excel_dosya}' dosyasına aktarıldı.")
