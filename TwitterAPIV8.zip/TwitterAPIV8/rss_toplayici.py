﻿# rss_toplayici.py
# Geliştirilmiş RSS toplayıcı: requests + UA, retries, redirect handling, temizleme, yeni puanlama + sıkı içerik filtresi

import time
import re
import html
import logging
from datetime import datetime, timezone, timedelta
from email.utils import parsedate_to_datetime
import feedparser
import requests

from veritabani import haber_ekle  # mevcut DB fonksiyonunu kullanıyoruz

# Konfig
MAX_AGE_HOURS = 1
REQUEST_TIMEOUT = 10
RETRIES = 2
RETRY_DELAY = 1  # sn
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"

# RSS kaynakları
RSS_LISTESI = [
    ("https://www.hurriyet.com.tr/rss/anasayfa", "Hürriyet"),
    ("https://www.sozcu.com.tr/rss/anasayfa.xml", "Sözcü"),
    ("https://www.ntv.com.tr/gundem.rss", "NTV"),
    ("https://www.cnnturk.com/feed/rss/all/news", "CNN Türk"),
    ("https://rss.haberturk.com/rss", "Habertürk"),
    ("https://www.trthaber.com/rss/anasayfa.rss", "TRT Haber"),
    ("https://www.milliyet.com.tr/rss/rssnew/dunya.xml", "Milliyet"),
    ("https://www.turkiyegazetesi.com.tr/rss.xml", "Türkiye Gazetesi"),
    ("https://www.dunya.com/rss", "Dünya"),
    ("https://www.ahaber.com.tr/rss/news.xml", "A Haber"),
    ("https://www.aa.com.tr/tr/rss/default?cat=guncel", "Anadolu Ajansı"),
    ("https://feeds.bbci.co.uk/turkce/rss.xml", "BBC Türkçe"),
    ("https://tr.euronews.com/rss?format=mrss", "Euronews Türkçe"),
    ("https://www.aljazeera.com/xml/rss/all.xml", "Al Jazeera"),
    ("https://www.reuters.com/rssFeed/worldNews", "Reuters"),
    ("https://www.aykiri.com.tr/rss/haber", "Aykırı"),
    ("https://press.tr/rss/gundem", "Press Haber"),
    ("https://ekoturkhaber.com/rss/gundem", "EkoTürk"),
    ("https://gazeteturk.com.tr/rss.xml", "GazeteTürk"),
    ("https://odatv4.com/rss.php", "OdaTV")
]

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")


# ----------------------------------------------------------
# HELPER FUNCTIONS
# ----------------------------------------------------------

def http_get(url):
    headers = {"User-Agent": USER_AGENT}
    last_exc = None
    for _ in range(RETRIES + 1):
        try:
            return requests.get(url, headers=headers, timeout=REQUEST_TIMEOUT, allow_redirects=True)
        except Exception as e:
            last_exc = e
            time.sleep(RETRY_DELAY)
    raise last_exc


def temizle_html(metin):
    if not metin:
        return ""
    metin = re.sub(r"<script[\s\S]*?</script>", "", metin, flags=re.IGNORECASE)
    metin = re.sub(r"<style[\s\S]*?</style>", "", metin, flags=re.IGNORECASE)
    metin = re.sub(r"<[^>]+>", "", metin)
    metin = html.unescape(metin)
    return re.sub(r"\s{2,}", " ", metin).strip()


def _parse_published(entry):
    pub = getattr(entry, "published", None) or getattr(entry, "updated", None) or getattr(entry, "pubDate", None)
    if not pub:
        return None
    try:
        dt = parsedate_to_datetime(pub)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except:
        try:
            s = pub.replace("Z", "+00:00")
            dt = datetime.fromisoformat(s)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except:
            return None


STOPWORDS = set(["ve","bir","bu","ile","için","de","da","ki","ne","o","ben","sen","biz","onu","gibi","daha"])
def extract_tags(text, top_n=5):
    words = re.findall(r"[A-Za-zÇŞĞÜÖİçşğüöı]+", text.lower())
    words = [w for w in words if len(w) > 3 and w not in STOPWORDS]
    freq = {}
    for w in words: freq[w] = freq.get(w, 0) + 1
    top = sorted(freq.items(), key=lambda x: x[1], reverse=True)[:top_n]
    return ", ".join(["#" + w for w,_ in top])


# ----------------------------------------------------------
# PUANLAMA SİSTEMİ (V3)
# ----------------------------------------------------------

ANAHTAR_KELIMELER = {
    "son dakika":6,"flaş":5,"acil":5,"patlama":6,"yangın":5,"deprem":6,
    "kaza":5,"ekonomi":4,"zam":4,"enflasyon":4,"faiz":3,"altın":3,
    "dolar":3,"seçim":5,"futbol":2
}

KAYNAK_PUAN = {
    "Anadolu Ajansı":5,"BBC Türkçe":4,"Reuters":4,"NTV":3,"TRT Haber":3,
    "Al Jazeera":3,"Hürriyet":3,"CNN Türk":3
}

def puan_v3(baslik, ozet, etiketler, kaynak):
    toplam = 0
    l = len(baslik)
    if l < 20: toplam += 0
    elif l < 50: toplam += 2
    elif l < 120: toplam += 3
    else: toplam += 1

    o = len(ozet)
    if o < 40: toplam += 0
    elif o < 120: toplam += 1
    elif o < 300: toplam += 2
    else: toplam += 3

    for k, p in ANAHTAR_KELIMELER.items():
        if k in (baslik + " " + ozet).lower():
            toplam += p

    tag_say = len([t for t in etiketler.split(",") if t.strip()])
    if tag_say <= 2: toplam += 1
    elif tag_say <= 5: toplam += 2
    else: toplam += 3

    toplam += KAYNAK_PUAN.get(kaynak, 1)

    return toplam


# ----------------------------------------------------------
# ANA FONKSİYON (RSS ÇEKER)
# ----------------------------------------------------------

def rss_haberleri_cek():
    haber_listesi = []

    for url, kaynak in RSS_LISTESI:
        try:
            try:
                r = http_get(url)
                status = r.status_code
            except Exception:
                r = None
                status = None

            print(f"🔍 {kaynak} kaynak kontrol ediliyor...", end=" ")

            if r and r.status_code == 200:
                feed = feedparser.parse(r.text)
            else:
                feed = feedparser.parse(url)

            bulunan = 0

            for entry in feed.entries:
                baslik = temizle_html(getattr(entry, "title", "") or "")
                ozet = temizle_html(getattr(entry, "summary", getattr(entry, "description", "")) or "")
                link = (getattr(entry, "link", "") or "").strip()

                if not baslik or not link:
                    continue

                # ----------------------------------------------------------
                # 🚨 SIKILAŞTIRILMIŞ İÇERİK FİLTRESİ
                # ----------------------------------------------------------
                if len(baslik) < 35:
                    continue
                if len(ozet) < 70:
                    continue
                if len(baslik + " " + ozet) < 150:
                    continue
                # ----------------------------------------------------------

                dt = _parse_published(entry) or datetime.utcnow().replace(tzinfo=timezone.utc)
                age = datetime.now(timezone.utc) - dt
                if age > timedelta(hours=MAX_AGE_HOURS):
                    continue

                etiketler = extract_tags(baslik + " " + ozet)
                puan = puan_v3(baslik, ozet, etiketler, kaynak)

                dt_tr = dt.astimezone()
                haber_tarihi = dt_tr.strftime("%Y-%m-%d %H:%M:%S")
                cekim_tarihi = datetime.now().astimezone().isoformat()

                try:
                    added = haber_ekle(baslik, ozet, link, etiketler, puan, kaynak, haber_tarihi, cekim_tarihi)
                except:
                    added = False

                if added:
                    bulunan += 1
                    haber_listesi.append({
                        "baslik": baslik,
                        "ozet": ozet,
                        "link": link,
                        "etiketler": etiketler,
                        "puan": puan,
                        "kaynak": kaynak,
                        "haber_tarihi": haber_tarihi,
                        "cekim_tarihi": cekim_tarihi
                    })

            print(f"({bulunan} haber)")

        except Exception as e:
            print(f"❌ Hata ({kaynak}): {e}")

    return haber_listesi


if __name__ == "__main__":
    print("🚀 RSS test çalıştırılıyor...")
    h = rss_haberleri_cek()
    print(f"Toplam yeni haber: {len(h)}")
