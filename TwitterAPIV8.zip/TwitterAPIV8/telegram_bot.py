﻿# 🤖 telegram_bot.py (final sürüm - yerel saat düzeltmesi + HTML temizleme + Türkçe tarih formatı)
import os
import telebot
import locale
import hashlib
import urllib.parse
import re
import html
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from dotenv import load_dotenv
from veritabani import (
    telegram_gonderildi_mi,
    telegram_gonderildi_guncelle,
    link_kaydet,
    link_getir
)

# Ortam değişkenlerini yükle
load_dotenv()

# Türkçe tarih formatı
try:
    locale.setlocale(locale.LC_TIME, "tr_TR.UTF-8")
except Exception:
    try:
        locale.setlocale(locale.LC_TIME, "turkish")
    except Exception:
        pass

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

bot = telebot.TeleBot(TELEGRAM_TOKEN)


def temizle_etiketler(etiketler):
    """Etiketleri #formatına çevirir"""
    if not etiketler:
        return ""
    etiketler = re.split(r"[,\s]+", etiketler)
    duzgunler = []
    for etiket in etiketler:
        if not etiket.strip():
            continue
        temiz = (
            etiket.strip()
            .replace("ç", "c").replace("ğ", "g").replace("ı", "i")
            .replace("ö", "o").replace("ş", "s").replace("ü", "u")
        )
        if not temiz.startswith("#"):
            temiz = "#" + temiz
        duzgunler.append(temiz)
    return " ".join(duzgunler)


def temizle_html(metin):
    """HTML etiketlerini ve entity'leri temizler"""
    if not metin:
        return ""
    metin = re.sub(r"<[^>]+>", "", metin)
    metin = html.unescape(metin)
    metin = re.sub(r"\s{2,}", " ", metin)
    return metin.strip()


def _parse_any_date(date_str):
    """RSS tarihlerini parse eder"""
    if not date_str:
        return None
    try:
        dt = parsedate_to_datetime(date_str)
        if dt and not dt.tzinfo:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        pass
    try:
        s = date_str.strip()
        if s.endswith("Z"):
            s = s[:-1]
            dt = datetime.fromisoformat(s).replace(tzinfo=timezone.utc)
        else:
            dt = datetime.fromisoformat(s)
            if not dt.tzinfo:
                dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        return None


def tarih_farki_str(haber_tarihi_str):
    """Yayınlanma tarihini sistemin yerel saatine göre gösterir ve kaç dakika önce olduğunu ekler."""
    try:
        dt = _parse_any_date(haber_tarihi_str)
        if not dt:
            return haber_tarihi_str

        # Eğer tz yoksa UTC kabul et
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)

        # Yerel saate dönüştür (ör: Türkiye’de +03)
        dt_local = dt  
        simdi_local = datetime.now().astimezone()

        fark = simdi_local - dt_local
        dakika = int(fark.total_seconds() // 60)

        if dakika < 1:
            fark_str = "az önce"
        elif dakika < 60:
            fark_str = f"{dakika} dakika önce"
        else:
            saat = dakika // 60
            fark_str = f"{saat} saat önce"

        tarih_str = dt_local.strftime("%d %B %Y, %H:%M")
        return f"{tarih_str} ({fark_str})"

    except Exception as e:
        print(f"❌ Tarih biçimleme hatası: {e}")
        return haber_tarihi_str


def telegrama_haber_gonder(baslik, ozet, link, etiketler, puan, kaynak=None, haber_tarihi=None):
    """Haberleri Telegram kanalına gönderir"""
    try:
        if telegram_gonderildi_mi(link):
            return False

        # HTML etiketlerini temizle
        baslik = temizle_html(baslik)
        ozet = temizle_html(ozet)

        # Türkçe tarih + kaç dakika önce
        if haber_tarihi:
            haber_tarihi = tarih_farki_str(haber_tarihi)

        etiketler = temizle_etiketler(etiketler)

        mesaj = (
            f"📰 <b>{baslik}</b>\n\n"
            f"{ozet}\n\n"
            f"🏷️ <b>Etiketler:</b> {etiketler}\n"
            f"⭐ <b>Puan:</b> {puan}\n"
            f"📅 <b>Tarih:</b> {haber_tarihi}\n\n"
            f"🔗 {link}"
        )

        link_id = hashlib.md5(link.encode()).hexdigest()[:10]
        link_kaydet(link_id, link)

        markup = telebot.types.InlineKeyboardMarkup()
        markup.add(
            telebot.types.InlineKeyboardButton("📤 X’te Paylaş", callback_data=f"paylas|{link_id}")
        )

        bot.send_message(TELEGRAM_CHAT_ID, mesaj, parse_mode="HTML", reply_markup=markup)
        telegram_gonderildi_guncelle(link)
        return True

    except Exception as e:
        print(f"❌ Telegram gönderim hatası: {e}")
        return False


@bot.callback_query_handler(func=lambda call: True)
def callback_yakala(call):
    """Telegram’daki buton tıklamasını yakalar"""
    if call.data.startswith("paylas|"):
        link_id = call.data.split("|")[1]
        link = link_getir(link_id)

        if not link:
            bot.answer_callback_query(call.id, "❌ Bağlantı bulunamadı.")
            return

        try:
            mesaj_satirlari = call.message.text.split("\n")

            ozet = mesaj_satirlari[2].strip() if len(mesaj_satirlari) > 2 else ""
            etiket_satiri = [satir for satir in mesaj_satirlari if "🏷️" in satir]
            etiketler = etiket_satiri[0].replace("🏷️ Etiketler:", "").strip() if etiket_satiri else ""
            etiketler = temizle_etiketler(etiketler)

            tweet_metin = f"{ozet}\n\n{etiketler}\n\n{link}"
            tweet_url = f"https://twitter.com/intent/tweet?text={urllib.parse.quote(tweet_metin)}"

            bot.answer_callback_query(call.id, "📤 Tweet ekranı açılıyor...", show_alert=False)
            bot.send_message(
                TELEGRAM_CHAT_ID,
                f"🐦 Tweet oluşturmak için bağlantıya tıklayın:\n{tweet_url}"
            )

            print("\n───────────────────────────────")
            print("📤 X paylaşım linki oluşturuldu:")
            print(tweet_url)
            print("───────────────────────────────\n")

        except Exception as e:
            print(f"❌ Callback hata: {e}")
            bot.answer_callback_query(call.id, "❌ Paylaşım hatası oluştu.")


def telegram_bot_baslat():
    print("🤖 Telegram bot dinlemede...")
    bot.infinity_polling()
