import sqlite3
from datetime import datetime

DB_PATH = "veritabani.db"

def baglanti():
    return sqlite3.connect(DB_PATH)

def veritabani_olustur():
    conn = baglanti()
    c = conn.cursor()
    c.execute("""
    CREATE TABLE IF NOT EXISTS haberler (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        baslik TEXT,
        ozet TEXT,
        link TEXT UNIQUE,
        etiketler TEXT,
        puan INTEGER DEFAULT 0,
        kaynak TEXT,
        haber_tarihi TEXT,
        cekim_tarihi TEXT,
        telegram_gonderildi INTEGER DEFAULT 0,
        x_paylasildi INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        link_id TEXT
    )
    """)
    conn.commit()
    conn.close()

def haber_ekle(baslik, ozet, link, etiketler, puan, kaynak, haber_tarihi, cekim_tarihi):
    try:
        conn = baglanti()
        c = conn.cursor()
        c.execute("""
        INSERT OR IGNORE INTO haberler
        (baslik, ozet, link, etiketler, puan, kaynak, haber_tarihi, cekim_tarihi)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (baslik, ozet, link, etiketler, puan, kaynak, haber_tarihi, cekim_tarihi))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"❌ Hata (haber_ekle): {e}")
        return False

def telegram_gonderildi_mi(link):
    conn = baglanti()
    c = conn.cursor()
    c.execute("SELECT telegram_gonderildi FROM haberler WHERE link=?", (link,))
    sonuc = c.fetchone()
    conn.close()
    return sonuc and sonuc[0] == 1

def telegram_gonderildi_guncelle(link):
    conn = baglanti()
    c = conn.cursor()
    c.execute("UPDATE haberler SET telegram_gonderildi=1 WHERE link=?", (link,))
    conn.commit()
    conn.close()

def x_paylasildi_guncelle(link):
    conn = baglanti()
    c = conn.cursor()
    c.execute("UPDATE haberler SET x_paylasildi=1 WHERE link=?", (link,))
    conn.commit()
    conn.close()

def link_kaydet(link_id, link):
    conn = baglanti()
    c = conn.cursor()
    c.execute("UPDATE haberler SET link_id=? WHERE link=?", (link_id, link))
    conn.commit()
    conn.close()

def link_getir(link_id):
    conn = baglanti()
    c = conn.cursor()
    c.execute("SELECT link FROM haberler WHERE link_id=?", (link_id,))
    sonuc = c.fetchone()
    conn.close()
    return sonuc[0] if sonuc else None

def tum_haberleri_getir():
    conn = baglanti()
    c = conn.cursor()
    c.execute("SELECT * FROM haberler ORDER BY id DESC")
    haberler = c.fetchall()
    conn.close()
    return haberler
