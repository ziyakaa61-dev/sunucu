import os
from dotenv import load_dotenv
import tweepy

load_dotenv()

def x_paylas(link):
    api_key = os.getenv("X_API_KEY")
    api_secret = os.getenv("X_API_SECRET")
    access_token = os.getenv("X_ACCESS_TOKEN")
    access_secret = os.getenv("X_ACCESS_SECRET")

    client = tweepy.Client(
        consumer_key=api_key,
        consumer_secret=api_secret,
        access_token=access_token,
        access_token_secret=access_secret
    )
    client.create_tweet(text=f"📰 Yeni haber: {link}")
    print(f"🐦 X'e paylaşıldı: {link}")
