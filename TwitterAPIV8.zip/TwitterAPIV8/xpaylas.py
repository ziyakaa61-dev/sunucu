import tweepy
import os
from dotenv import load_dotenv

load_dotenv()

# X (Twitter) API bilgileri
X_API_KEY = os.getenv("TWITTER_API_KEY")
X_API_SECRET = os.getenv("TWITTER_API_SECRET")
X_ACCESS_TOKEN = os.getenv("TWITTER_ACCESS_TOKEN")
X_ACCESS_SECRET = os.getenv("TWITTER_ACCESS_SECRET")

auth = tweepy.OAuth1UserHandler(
    X_API_KEY,
    X_API_SECRET,
    X_ACCESS_TOKEN,
    X_ACCESS_SECRET
)
api = tweepy.API(auth)


def x_paylas(ozet, link, etiketler="", tarih=""):
    """
    Haberi X'e (Twitter'a) paylaşır.
    Başlık artık paylaşılmaz.
    """
    try:
        ozet = (ozet or "").strip().replace("\n", " ")
        link = (link or "").strip()

        # Linkler X'te her zaman 23 karakter olarak sayılır
        max_length = 280 - 23 - 5  # 5 karakter güvenlik payı

        # Özet çok uzunsa kısalt
        if len(ozet) > max_length:
            ozet = ozet[:max_length - 3] + "..."

        # Nihai tweet metni
        tweet = f"{ozet}\n\n{link}"

        # Konsola önizleme
        print("\n───────────────────────────────")
        print("📤 X'e gönderilmeye çalışılan tweet:")
        print(tweet)
        print(f"\n🔢 Gönderilen karakter: {len(ozet)} + 23 (link) = {len(ozet) + 23}")
        print("───────────────────────────────\n")

        # Tweet gönderimi
        api.update_status(tweet)
        print(f"✅ X'e paylaşıldı ({len(tweet)} karakter)")
        return True

    except Exception as e:
        print(f"❌ X paylaşım hatası: {e}")
        return False
