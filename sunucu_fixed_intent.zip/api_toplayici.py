# api_toplayici.py
# API Toplayıcı: GNews, NewsAPI, Mediastack - rate-limit tolerant, backoff, disable-on-limit
import os
import time
import requests
import html
import re
from datetime import datetime, timezone, timedelta
from dotenv import load_dotenv

from veritabani import haber_ekle

load_dotenv()

GNEWS_KEY = os.getenv("GNEWS_API_KEY")
NEWSAPI_KEY = os.getenv("NEWSAPI_KEY")
MEDIASTACK_KEY = os.getenv("MEDIASTACK_API_KEY")

USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"

# Basit state: api_enabled ve disable_until timestamp (rate limit yönetimi)
API_STATE = {
    "GNews": {"enabled": True, "disabled_until": None},
    "NewsAPI": {"enabled": True, "disabled_until": None},
    "Mediastack": {"enabled": True, "disabled_until": None}
}

REQUEST_TIMEOUT = 10

# Temizleme & etiket çıkarıcı (paylaşılan kodla uyumlu)
def temizle_html(metin):
    if not metin: return ""
    metin = re.sub(r"<[^>]+>", "", metin)
    return html.unescape(metin).strip()

def extract_tags(text, top_n=5):
    words = re.findall(r"[A-Za-zÇŞĞÜÖİçşğüöı]+", (text or "").lower())
    words = [w for w in words if len(w) > 3]
    freq = {}
    for w in words: freq[w] = freq.get(w,0) + 1
    top = sorted(freq.items(), key=lambda x: x[1], reverse=True)[:top_n]
    return ", ".join(["#" + w for w,_ in top])

def puan_v3(baslik, ozet, etiketler, kaynak):
    # Burada rss_toplayici ile aynı puan fonksiyonu kullan
    from rss_toplayici import puan_v3 as rss_puan
    return rss_puan(baslik, ozet, etiketler, kaynak)

def _kaydet_ve_formatla(kaynak, title, desc, url, published):
    title = temizle_html(title)
    desc = temizle_html(desc)
    tags = extract_tags(title + " " + desc)
    puan = puan_v3(title, desc, tags, kaynak)
    # published ISO tolerant
    try:
        dt = datetime.fromisoformat(published.replace("Z", "+00:00"))
    except Exception:
        dt = datetime.now(timezone.utc)
    tarih = dt.astimezone().strftime("%Y-%m-%d %H:%M:%S")
    cekim = datetime.now().astimezone().isoformat()
    try:
        added = haber_ekle(title, desc, url, tags, puan, kaynak, tarih, cekim)
    except Exception:
        added = False
    if added:
        return {"baslik": title, "ozet": desc, "link": url, "etiketler": tags, "puan": puan, "kaynak": kaynak, "haber_tarihi": tarih, "cekim_tarihi": cekim}
    return None

def _disable_api(name, seconds=3600):
    API_STATE[name]["enabled"] = False
    API_STATE[name]["disabled_until"] = time.time() + seconds
    print(f"⚠️ {name} API geçici olarak devre dışı bırakıldı ({seconds}s)")

def _maybe_reenable():
    for name, st in API_STATE.items():
        if not st["enabled"] and st["disabled_until"] and time.time() > st["disabled_until"]:
            st["enabled"] = True
            st["disabled_until"] = None
            print(f"ℹ️ {name} API yeniden etkinleştirildi")

# ---------------- GNews ----------------
def gnews_cek():
    _maybe_reenable()
    if not API_STATE["GNews"]["enabled"]:
        return []
    if not GNEWS_KEY:
        return []

    url = f"https://gnews.io/api/v4/top-headlines?lang=tr&country=tr&token={GNEWS_KEY}"
    try:
        r = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=REQUEST_TIMEOUT)
        if r.status_code == 403 or r.status_code == 429:
            # limitlenme
            _disable_api("GNews", seconds=3600*6)  # 6 saat kapat
            return []
        r.raise_for_status()
        data = r.json()
        items = []
        for a in data.get("articles", []):
            saved = _kaydet_ve_formatla("GNews", a.get("title"), a.get("description"), a.get("url"), a.get("publishedAt") or datetime.now(timezone.utc).isoformat())
            if saved: items.append(saved)
        print(f"🔍 GNews API → {len(items)} haber bulundu")
        return items
    except Exception as e:
        print("❌ GNews hata:", e)
        return []

# ---------------- NewsAPI ----------------
def newsapi_cek():
    _maybe_reenable()
    if not API_STATE["NewsAPI"]["enabled"]: return []
    if not NEWSAPI_KEY: return []

    url = f"https://newsapi.org/v2/top-headlines?country=tr&language=tr&apiKey={NEWSAPI_KEY}"
    try:
        r = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=REQUEST_TIMEOUT)
        if r.status_code == 429:
            _disable_api("NewsAPI", seconds=3600*6)
            return []
        r.raise_for_status()
        data = r.json()
        items = []
        for a in data.get("articles", []):
            saved = _kaydet_ve_formatla("NewsAPI", a.get("title"), a.get("description"), a.get("url"), a.get("publishedAt") or datetime.now(timezone.utc).isoformat())
            if saved: items.append(saved)
        print(f"🔍 NewsAPI → {len(items)} haber bulundu")
        return items
    except Exception as e:
        print("❌ NewsAPI hata:", e)
        return []

# ---------------- Mediastack ----------------
def mediastack_cek():
    _maybe_reenable()
    if not API_STATE["Mediastack"]["enabled"]: return []
    if not MEDIASTACK_KEY: return []

    url = f"http://api.mediastack.com/v1/news?access_key={MEDIASTACK_KEY}&countries=tr&languages=tr"
    try:
        r = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=REQUEST_TIMEOUT)
        if r.status_code == 429:
            _disable_api("Mediastack", seconds=3600*6)
            return []
        r.raise_for_status()
        data = r.json()
        items = []
        for a in data.get("data", []):
            saved = _kaydet_ve_formatla("Mediastack", a.get("title"), a.get("description"), a.get("url"), a.get("published_at") or datetime.now(timezone.utc).isoformat())
            if saved: items.append(saved)
        print(f"🔍 Mediastack → {len(items)} haber bulundu")
        return items
    except Exception as e:
        print("❌ Mediastack hata:", e)
        return []

def tum_api_haberleri():
    out = []
    out.extend(gnews_cek())
    out.extend(newsapi_cek())
    out.extend(mediastack_cek())
    return out
