﻿# main.py
import os
os.system('title 🇹🇷 TR Gündem Botu')

import time
import threading
from datetime import datetime

from rss_toplayici import rss_haberleri_cek
from api_toplayici import tum_api_haberleri
from veritabani import veritabani_olustur
from telegram_bot import telegrama_haber_gonder, telegram_bot_baslat, temizle_html

MIN_PUAN = 12  # istersen 0 yapabilirsin

def log(m):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {m}")

def telegram_thread():
    try:
        telegram_bot_baslat()
    except Exception as e:
        log(f"❌ Telegram bot başlatılamadı: {e}")

def haber_dongusu():
    while True:
        log("🌐 RSS haberleri çekiliyor...")
        rss_haberler = rss_haberleri_cek()
        log(f"📡 RSS → {len(rss_haberler)} yeni haber bulundu")

        log("🌐 API haberleri çekiliyor...")
        api_haberler = tum_api_haberleri()
        log(f"📡 API → {len(api_haberler)} yeni haber bulundu")

        toplam = rss_haberler + api_haberler
        log(f"📰 Toplam yeni haber: {len(toplam)}")

        gonderilen = 0
        for h in toplam:
            try:
                if h.get("puan", 0) < MIN_PUAN:
                    continue
                # telegrama_haber_gonder veritabanı duplicate kontrolü zaten yapıyor; tekrar kontrol etmek istemiyorsan atla
                sent = telegrama_haber_gonder(
                    h["baslik"], h["ozet"], h["link"], h.get("etiketler", ""), h.get("puan",0), h.get("kaynak"), h.get("haber_tarihi")
                )
                if sent:
                    gonderilen += 1
                    log(f"📤 Gönderildi: {h['baslik'][:80]}...")
            except Exception as e:
                log(f"❌ Haber gönderim hatası: {e}")

        log(f"🎯 Bu döngüde toplam gönderilen: {gonderilen}")

        # 5 dakika bekleme (300s)
        for s in range(300, 0, -1):
            print(f"\r⏳ Yeni çekim için bekleniyor: {s//60:02d}:{s%60:02d}", end="", flush=True)
            time.sleep(1)
        print()

if __name__ == "__main__":
    log("🧠 Veritabanı kontrol ediliyor...")
    veritabani_olustur()

    log("🤖 Telegram bot arka planda başlatılıyor...")
    bot_thread = threading.Thread(target=telegram_thread, daemon=True)
    bot_thread.start()

    log("🚀 Haber döngüsü başlatılıyor...\n")
    haber_dongusu()
 