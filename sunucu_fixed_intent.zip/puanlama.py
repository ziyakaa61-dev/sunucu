# 🔮 puanlama.py (Geliştirilmiş versiyon)
# Haberin başlığı, özeti ve etiketlerine göre puanlama yapar.

def haber_puani_hesapla(baslik: str, ozet: str, etiketler: str) -> int:
    # 🔹 Kategorilere ayrılmış puanlama tablosu
    kelime_puanlari = {
        # 🔸 Gündem / Son Dakika
        "son dakika": 5,
        "flaş": 4,
        "acil": 4,
        "şok": 3,
        "önemli": 3,
        "gündem": 2,
        "olay": 2,
        "gelişme": 2,
        "skandal": 3,
        "saldırı": 4,
        "patlama": 4,
        "yangın": 3,
        "facial": 4,
        "kaza": 3,
        "ölüm": 3,
        "yaralı": 2,

        # 🔸 Afet / Doğa
        "deprem": 5,
        "fırtına": 4,
        "sel": 4,
        "heyelan": 3,
        "kar": 2,
        "yağmur": 2,
        "meteoroloji": 3,
        "hava durumu": 2,
        "afet": 3,

        # 🔸 Ekonomi
        "zam": 3,
        "enflasyon": 3,
        "faiz": 3,
        "dolar": 3,
        "euro": 3,
        "altın": 3,
        "borsa": 2,
        "kripto": 3,
        "bitcoin": 3,
        "ekonomi": 2,
        "vergi": 2,
        "maaş": 2,
        "asgari ücret": 4,
        "piyasa": 2,

        # 🔸 Politika / Hukuk
        "seçim": 4,
        "cumhurbaşkanı": 3,
        "bakan": 3,
        "kararname": 2,
        "yasa": 2,
        "mahkeme": 3,
        "tutuklandı": 3,
        "hapis": 3,
        "dava": 2,
        "tbmm": 2,
        "ankara": 1,

        # 🔸 Teknoloji
        "yapay zeka": 4,
        "teknoloji": 3,
        "uygulama": 2,
        "inovasyon": 2,
        "gadget": 1,
        "bilgisayar": 1,
        "apple": 1,
        "samsung": 1,
        "openai": 3,
        "chatgpt": 3,
        "robot": 2,

        # 🔸 Spor
        "futbol": 2,
        "basketbol": 2,
        "voleybol": 2,
        "transfer": 3,
        "galatasaray": 2,
        "fenerbahçe": 2,
        "beşiktaş": 2,
        "maç": 2,
        "gol": 2,
        "puan durumu": 1,
        "derbi": 2,

        # 🔸 Toplum / Eğitim / Sağlık
        "okul": 1,
        "eğitim": 2,
        "öğrenci": 2,
        "öğretmen": 2,
        "sağlık": 2,
        "hastalık": 2,
        "koronavirüs": 3,
        "covid": 3,
        "aşı": 2,
        "hastane": 2,
        "vakıf": 1,

        # 🔸 Genel
        "açıklama": 2,
        "röportaj": 1,
        "video": 1,
        "görüntü": 1,
        "iddia": 1,
        "skandal": 2,
        "duyuru": 1
    }

    metin = f"{baslik.lower()} {ozet.lower()} {etiketler.lower()}"
    puan = 0

    for kelime, agirlik in kelime_puanlari.items():
        if kelime in metin:
            puan += agirlik

    # Kelime çeşitliliği varsa küçük bonus
    if len(set(metin.split())) > 30:
        puan += 1

    return puan
