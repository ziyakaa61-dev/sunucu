import os
import tweepy
from dotenv import load_dotenv

load_dotenv()

def x_api_baglan():
    api_key = os.getenv("TWITTER_API_KEY")
    api_secret = os.getenv("TWITTER_API_SECRET")
    access_token = os.getenv("TWITTER_ACCESS_TOKEN")
    access_secret = os.getenv("TWITTER_ACCESS_SECRET")

    auth = tweepy.OAuth1UserHandler(api_key, api_secret, access_token, access_secret)
    return tweepy.API(auth)

def x_paylas(baslik, ozet, link, etiketler):
    api = x_api_baglan()

    # Mesajı oluştur
    text = f"{baslik}\n\n{ozet}\n\n{etiketler}\n{link}"

    # 280 karakter sınırını koru
    if len(text) > 280:
        allowed_len = 270 - len(etiketler) - len(link)
        ozet = (ozet[:allowed_len] + "...") if len(ozet) > allowed_len else ozet
        text = f"{baslik}\n\n{ozet}\n\n{etiketler}\n{link}"

    try:
        api.update_status(text)
        print(f"🐦 X'te paylaşıldı: {baslik[:50]}...")
    except Exception as e:
        print(f"❌ X paylaşım hatası: {e}")
