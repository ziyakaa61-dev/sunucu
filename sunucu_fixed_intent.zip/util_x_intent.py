# util_x_intent.py
import urllib.parse

X_LINK_LENGTH = 23
TWEET_LIMIT = 280

def build_tweet_text(format_kind, baslik="", ozet="", link="", etiketler=""):
    baslik = (baslik or "").strip().replace("\n", " ")
    ozet = (ozet or "").strip().replace("\n", " ")
    link = (link or "").strip()
    etiketler = (etiketler or "").strip()

    if format_kind == "A":
        core = ozet
    elif format_kind == "B":
        core = f"{baslik}\\n\\n{ozet}"
    elif format_kind == "C":
        core = f"{baslik}\\n\\n{ozet}\\n\\n{etiketler}"
    elif format_kind == "D":
        core = f"{ozet}\\n\\n{etiketler}"
    else:
        core = f"{baslik}\\n\\n{ozet}"

    link_len = X_LINK_LENGTH if link else 0
    safe_margin = 3
    allowed_core_len = TWEET_LIMIT - link_len - (1 if link else 0) - safe_margin

    if len(core) > allowed_core_len:
        core = core[:allowed_core_len] + "..."

    tweet_text = core
    if link:
        tweet_text = tweet_text.strip() + f"\\n\\n{link}"

    return tweet_text

def intent_url_for_tweet(text):
    return "https://twitter.com/intent/tweet?text=" + urllib.parse.quote(text)