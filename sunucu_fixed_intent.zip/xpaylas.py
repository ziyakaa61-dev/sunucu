# xpaylas.py (intent-only)
from util_x_intent import build_tweet_text, intent_url_for_tweet

def x_intent_url(format_kind, baslik="", ozet="", link="", etiketler=""):
    text = build_tweet_text(format_kind, baslik=baslik, ozet=ozet, link=link, etiketler=etiketler)
    return intent_url_for_tweet(text)